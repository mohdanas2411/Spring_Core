package com.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.spring.beans.Address;

@Configuration
@ComponentScan("com.spring")
public class MyConfig {
	
	@Bean
	public Address address1() {
		return new Address();
	}
	
	@Bean
	public Address address2() {
		return new Address();
	}
}
