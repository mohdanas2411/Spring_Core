package com.spring.beans;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.beans.Address;

@Component
public class Student {
	@Autowired
	private List<Address> address;
	
	public Student() {
		System.out.println("Student Default Constructor");
	}
	
	public void display() {
		System.out.println("Inside Student Display()");
		address.get(0).show();;
		address.get(1).show();;
	}
}
