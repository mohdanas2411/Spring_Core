package com.spring.beans;

public class Address {
	private int id;
	public Address(int id) {
		System.out.println("Address parameterized Constructor");
		this.id=id;
	}
	
	public void show() {
		System.out.println("Inside Address show method");
		System.out.println("id = "+id);
	}
}
