package com.spring.beans;

import com.spring.beans.Address;

public class Student {
	private Address[] address;
	
	public Student(Address[] address) {
		System.out.println("Student parameterised Constructor");
		this.address=address;
	}
	
	public void display() {
		System.out.println();
		for(Address obj : address) {
			obj.show();
		}
	}
}
