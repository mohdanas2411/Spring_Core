package com.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.beans.Emails;

public class MyApplication {
	public static void main(String[] args) {
		System.out.println("Inside Application Context");
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
		
		Emails e1 = context.getBean("getEmails",Emails.class);
		e1.display();
		context.close();
	}
}
