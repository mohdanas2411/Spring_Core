package com.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import com.spring.beans.Emails;

@Configuration
@PropertySource("DBDetails.property")
public class MyConfig {
	
	@Bean
	public Emails getEmails() { //by default bean id = getEmails
		return new Emails();
	}
}
