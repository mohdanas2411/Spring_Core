package com.spring.beans;

import org.springframework.beans.factory.annotation.Value;

public class Emails {
	@Value("${DB.Name}")
	private String DBName;
	@Value("${DB.Password}")
	private String PassWord;
	
	public Emails() {
		System.out.println("Emails Default Constructor");
	}
	
	public void display() {
		System.out.println("Db Name = "+DBName);
		System.out.println("Db Password = "+PassWord);
	}
	
}
