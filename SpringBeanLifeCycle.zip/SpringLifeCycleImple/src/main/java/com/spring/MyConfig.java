package com.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.objenesis.instantiator.annotations.Instantiator;

import com.spring.bean.LifeCycle;

@Configuration
@ComponentScan("com.spring")
public class MyConfig {
	
	@Bean(value="lifeCycle",initMethod="myCustomInit",destroyMethod="myCustomDestroy")
	public LifeCycle getInstance() {
		return new LifeCycle();
	}
}

