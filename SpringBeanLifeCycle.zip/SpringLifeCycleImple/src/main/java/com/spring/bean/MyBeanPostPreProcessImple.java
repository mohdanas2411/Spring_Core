package com.spring.bean;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

@Component
public class MyBeanPostPreProcessImple implements BeanPostProcessor {

	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {

		System.out.println("Inside postProcessBeforeInitialization(Object bean, String beanName) ()");

		if (bean instanceof LifeCycle) {
			LifeCycle lc = (LifeCycle) bean;
			lc.setName("Mohd " + lc.getName());
			System.out.println("******************************");
			return lc;
		} else {
			System.out.println("Class Name = " + bean.getClass().getName());
			return bean;
		}
	}

	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {

		System.out.println("Inside Object postProcessAfterInitialization(Object bean, String beanName)");
		if (bean instanceof LifeCycle) {
			LifeCycle lc = (LifeCycle) bean;
			lc.setName("Ansari " + lc.getName());
			System.out.println("******************************");
			return lc;
		} else {
			System.out.println("Class Name = " + bean.getClass().getName());
			return bean;
		}
	}
}
