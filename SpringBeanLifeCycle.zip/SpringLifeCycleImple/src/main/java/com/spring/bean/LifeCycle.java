package com.spring.bean;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanClassLoaderAware;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

public class LifeCycle implements BeanNameAware, BeanFactoryAware, BeanClassLoaderAware, ApplicationContextAware,
		InitializingBean, DisposableBean{

	@Value("Anas")
	private String name;

	public LifeCycle() {
		System.out.println("Inside LifeCycle Default Constructor");
		System.out.println("******************************");
	}

	public void setApplicationContext(ApplicationContext applicationContext) throws BeansException {
		System.out.println("Inside setApplicationContext(ApplicationContext applicationContext)");
		System.out.println("ApplicationContext Name is" + applicationContext.getClass().getName());
		System.out.println("******************************");
	}

	public void setBeanClassLoader(ClassLoader classLoader) {
		System.out.println("Inside setBeanClassLoader(ClassLoader classLoader)");
		System.out.println("setBeanClassLoader Name is = " + classLoader.getClass().getName());
		System.out.println("******************************");

	}

	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		System.out.println("Inside setBeanFactory(BeanFactory beanFactory)");
		System.out.println("setBeanFactory Name is = " + beanFactory.getClass().getName());
		System.out.println("******************************");

	}

	public void setBeanName(String name) {
		System.out.println("Inside setBeanName(String name)");
		System.out.println("setBeanName(String name is = " + name);
		System.out.println("******************************");

	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@PostConstruct
	public void PostConstruct() {
		System.out.println("Inside PostConstruct ()");
		System.out.println("Name in @PostConstruct is = " + this.name);
		System.out.println("******************************");
	}

	public void afterPropertiesSet() throws Exception {
		System.out.println("Inside afterPropertiesSet ()");
		this.name = "Ansari";
		System.out.println("Name in InitializingBean.afterPropertiesSet() is = " + this.name);
		System.out.println("******************************");
	}

	// custom init method configured in configuration file
	public void myCustomInit() {
		System.out.println("Inside myCustomInit ()");
		System.out.println("Name in myCustomInit() is = " + this.name);
		System.out.println("******************************");
	}

	@PreDestroy
	public void preDestroy() {
		System.out.println("Inside preDestroy ()");
		System.out.println("Name in @preDestroy() is = " + this.name);
		System.out.println("******************************");
	}

	public void destroy() throws Exception {
		System.out.println("Inside destroy ()");
		this.name = null;
		System.out.println("Name in DisposableBean.destroy() is = " + this.name);
		System.out.println("******************************");
	}

	// custom Destroy method configured in configuration file
	public void myCustomDestroy() {
		System.out.println("Inside myCustomDestroy ()");
		System.out.println("Name in myCustomDestroy() is = " + this.name);
		System.out.println("******************************");
	}

}
