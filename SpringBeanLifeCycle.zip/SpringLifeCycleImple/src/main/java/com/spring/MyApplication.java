package com.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.bean.LifeCycle;

public class MyApplication {

	public static void main(String[] args) {
		System.out.println("Inside MyApplication");
		System.out.println("******************************");
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
		LifeCycle bean = context.getBean("lifeCycle",LifeCycle.class);
		context.registerShutdownHook();
		
	}

}
