package com.spring.annotation.methodAutowired;

public class Address2 {
	public Address2() {
		System.out.println("Address2 Constructor");
	}
	
	public void show2() {
		System.out.println("inside Address2 show Method");
	}
}
