package com.spring.annotation.constructorAutowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("student") //equal to bean tag, by default id = Student1
@Scope("prototype")
public class Student1 {
	private Address1 address;

	@Autowired //Autowired by Constructor
	public Student1(Address1 address) {
		this.address = address;
	}
	
	public void display1() {
		System.out.println("inside student1 display method");
		address.show1();
	}
	
}
