package com.spring.annotation.propertyAutowired;

public class Address3 {
	public Address3() {
		System.out.println("Address Constructor of Property Autowired ");
	}
	
	public void show3() {
		System.out.println("inside Property Autowired show Method");
	}
}
