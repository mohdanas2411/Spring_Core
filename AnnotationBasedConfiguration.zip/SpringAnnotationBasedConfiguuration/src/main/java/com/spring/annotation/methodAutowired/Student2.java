package com.spring.annotation.methodAutowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("student2") //equal to bean tag, by default id = Student2
public class Student2 {
	private Address2 address;

	@Autowired //Autowired by Method
	public void setAddress(Address2 address) {
		System.out.println("Inside student setAddress method");
		this.address = address;
	}


	public void display2() {
		System.out.println("inside student2 display method");
		address.show2();
	}
	
}
