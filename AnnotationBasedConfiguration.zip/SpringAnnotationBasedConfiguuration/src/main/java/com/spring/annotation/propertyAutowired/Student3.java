package com.spring.annotation.propertyAutowired;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component("student3") //equal to bean tag, by default id = Student2
public class Student3 {

	@Autowired // by property
	private Address3 address;
	
	public Student3() {
		System.out.println("Student constructor of Property Autowired");
	}

	public void display3() {
		System.out.println("inside student2 display method of Property Autowired");
		address.show3();
	}
	
}
