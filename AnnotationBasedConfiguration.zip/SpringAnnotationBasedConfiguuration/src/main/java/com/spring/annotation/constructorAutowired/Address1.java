package com.spring.annotation.constructorAutowired;

import org.springframework.context.annotation.Scope;

@Scope("prototype")
public class Address1 {
	
	public Address1() {
		System.out.println("Address 1 Constructor");
	}
	
	public void show1() {
		System.out.println("inside Address1 show Method");
	}
}
