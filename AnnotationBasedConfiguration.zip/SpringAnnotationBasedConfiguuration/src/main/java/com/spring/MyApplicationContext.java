package com.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.annotation.constructorAutowired.Student1;
import com.spring.annotation.methodAutowired.Student2;
import com.spring.annotation.propertyAutowired.Student3;

public class MyApplicationContext {
	public static void main(String[] args) {
		System.out.println("Application Context");
		ApplicationContext context = new ClassPathXmlApplicationContext("MyConfiguration.xml");
		Student1 student1 = context.getBean("student",Student1.class);
		student1.display1();
		
		Student2 student2 = context.getBean("student2",Student2.class);
		student2.display2();
		
		Student3 student3 = context.getBean("student3",Student3.class);
		student3.display3();
		
		
	}
}
