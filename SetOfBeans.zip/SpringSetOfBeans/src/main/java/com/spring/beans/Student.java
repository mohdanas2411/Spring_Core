package com.spring.beans;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Student {
	@Autowired
	private Set<Address> address;
	
	public Student() {
		System.out.println("Student Default Constructor");
	}
	
	public void display() {
		System.out.println("Inside Student Display()");
		
		for (Address obj : address) {
			obj.show();
		}
	}
}
