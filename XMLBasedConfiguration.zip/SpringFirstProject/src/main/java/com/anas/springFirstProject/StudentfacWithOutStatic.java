package com.anas.springFirstProject;

public class StudentfacWithOutStatic {
	private String Name;
	private int id;
	
	public StudentfacWithOutStatic() {
		System.out.println("Contuctor invoked");
	}
	public StudentfacWithOutStatic createInstance(String name,int id) {
		StudentfacWithOutStatic stws = new StudentfacWithOutStatic();
		stws.Name=name;
		stws.id=id;
		return stws;
	}
	public void display() {
		System.out.println("name is "+Name+"Id is "+id);
	}
}
