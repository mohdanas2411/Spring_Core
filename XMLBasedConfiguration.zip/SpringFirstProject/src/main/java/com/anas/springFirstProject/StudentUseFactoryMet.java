package com.anas.springFirstProject;

public class StudentUseFactoryMet {
	private String name;
	private int id;

	public static StudentUseFactoryMet getInstance(String name, int id) {
		StudentUseFactoryMet sf = new StudentUseFactoryMet();
		sf.name = name;
		sf.id = id;
		return sf;
	}
	public void displayData() {
		System.out.println("Name is : "+name+" Id is : "+id);
	}
}
