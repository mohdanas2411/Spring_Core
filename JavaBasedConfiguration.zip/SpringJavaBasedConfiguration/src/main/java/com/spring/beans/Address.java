package com.spring.beans;

public class Address {

	public void show() {
		System.out.println("Inside Address Show() ");
	}
}
