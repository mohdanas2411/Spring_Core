package com.spring.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Student {
	
	@Autowired
	@Qualifier("add1")
	private  Address add;
	
	public Student() {
		System.out.println("Inside Student Constructor");
	}
	
	public void display() {
		System.out.println("Inside Student Display()");
		add.show();
	}
}
