package com.spring.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.spring.beans.Address;

@Configuration
@ComponentScan("com.spring") // scan all annotation
public class MyConfig {
	
	@Bean("add1") //replacement of <bean>
	public Address getInstance() {
		return new Address();
	}
	
	@Bean("add2") //replacement of <bean>
	public Address getInstance1() {
		return new Address();
	}
}
