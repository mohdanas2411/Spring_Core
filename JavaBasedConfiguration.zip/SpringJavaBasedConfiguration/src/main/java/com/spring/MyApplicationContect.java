package com.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.beans.Student;
import com.spring.config.MyConfig;

public class MyApplicationContect {

	public static void main(String[] args) {
		System.out.println("Inside MyApplication Context");
		
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
		Student s1 = context.getBean("student",Student.class);
		s1.display();
		
	}

}
