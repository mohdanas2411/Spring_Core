package com.spring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.beans.Student;

public class MyApplication {
	public static void main(String[] args) {
		System.out.println("Inside MyApplication");
		ApplicationContext context = new ClassPathXmlApplicationContext("spring_config.xml");
		Student parentBean = context.getBean("student",Student.class);
		Student childBean = context.getBean("child",Student.class);
		
		System.out.println("Values from Parent Bean");
		parentBean.display();
		
		System.out.println("Values from Child Bean");
		childBean.display();
	}
}
