package com.spring.beans;

public class Student {
	private String name,address;
	private  int roll;
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	
	public void display() {
		System.out.println("Inside Student Display Method");
		System.out.println("Name is :"+this.name+"\nRoll no is :"+this.roll+"\nAddress is :"+this.address);

	}
}
