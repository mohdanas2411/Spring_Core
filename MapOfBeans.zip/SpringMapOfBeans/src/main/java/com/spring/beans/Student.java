package com.spring.beans;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.beans.Address;

@Component
public class Student {
	@Autowired
	private Map<String,Address> address;
	
	public Student() {
		System.out.println("Student Default Constructor");
	}
	
	public void display() {
		System.out.println("Inside Student Display()");
		for (Entry<String, Address> es  : address.entrySet()) {
			System.out.println("Bean id is ="+es.getKey());
			es.getValue().show();
		}
	}
}
