package com.spring.beans;

public class Address {

	public Address() {
		System.out.println("Address Default Constructor");
	}
	
	public void show() {
		System.out.println("Inside Address show method");
	}
}
