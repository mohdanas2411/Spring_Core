package com.spring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.spring.beans.Student;

public class Application {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(MyConfig.class);
		Student s1 = context.getBean("student",Student.class);
		s1.display();
		context.close();
	}

}
